//variables
//suits = cards options 
//cardValues = cards values
// deck = Array of Objects of Cards, each card is an object with properties of Value, Suite and weight

// Creating the Cards
const suits = ["Spades", "Hearts", "Diamonds", "Clubs"];
const cardValues = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];

//Players 
let players = new Array();
let currentPlayer = 0;

//Cards Deck
let deck = new Array();

function startblackjack() {
    document.getElementById('btnStart').value = 'Restart';
    document.getElementById("hitBtn").removeAttribute("disabled");
    document.getElementById("stayBtn").removeAttribute("disabled");
    document.getElementById("status").style.display = "none";
    // deal 2 cards to every player object
    currentPlayer = 0;
    createDeck();
    shuffle();
    createPlayers(2);
    createPlayersUI();
    dealFirstHand();
    document.getElementById('player_' + currentPlayer).classList.add('active');
}

// function to create 52 cards in 1 Array of deck
function createDeck() {
    for (var i = 0; i < suits.length; i++) {
        for (var x = 0; x < cardValues.length; x++) {
            let weight = parseInt(cardValues[x]);
            if (cardValues[x] == "J" || cardValues[x] == "Q" || cardValues[x] == "K") {
                weight = 10;
            }
            if (cardValues[x] == "A") {
                weight = 11;
            }
            var card = {
                Value: cardValues[x],
                Suit: suits[i],
                Weight: weight
            }
            deck.push(card);
        }
    }
}

//Create the UI of the Players
function createPlayersUI() {
    document.getElementById('players').innerHTML = '';
    for (var i = 0; i < players.length; i++) {
        //Create DOM elements 
        var div_player = document.createElement('div');
        var div_playerid = document.createElement('div');
        var div_hand = document.createElement('div');
        var div_points = document.createElement('div');

        div_points.className = 'points';
        div_points.id = 'points_' + i;
        div_player.id = 'player_' + i;
        div_player.className = 'player';
        div_hand.id = 'hand_' + i;

        div_playerid.innerHTML = players[i].ID;
        div_player.appendChild(div_playerid);
        div_player.appendChild(div_hand);
        div_player.appendChild(div_points);
        document.getElementById('players').appendChild(div_player);
    }
}

//Shuffle Cards
function shuffle() {
    for (var i = 0; i < 1000; i++) {
        let deckIndx1 = Math.floor((Math.random() * deck.length));
        let deckIndx2 = Math.floor((Math.random() * deck.length));
        let tmp = deck[deckIndx1];

        deck[deckIndx1] = deck[deckIndx2];
        deck[deckIndx2] = tmp;
        console.log("deck before update " + deck.length)
    }
}

// create the Players object - the argument here is for the number of the players
function createPlayers(num) {
    for (var i = 1; i <= num; i++) {
        let hand = new Array();
        let player = {
            Name: 'Player ' + i,
            ID: i,
            Points: 0,
            Hand: hand,
        };
        players.push(player);
    }
}

//Deal 1st Hand - 2 cards per player
function dealFirstHand() {
    for (var i = 0; i < 2; i++) { // 2 cards to each player
        for (var x = 0; x < players.length; x++) {
            let card = deck.pop();
            players[x].Hand.push(card);
            renderCard(card, x);
            updatePoints();
        }
    }
    updateDeck();
}

//render the card into HTML using append
function renderCard(card, player) {
    var hand = document.getElementById('hand_' + player);
    hand.appendChild(getCardUI(card));
}

// returns the number of points that a player has in hand
function getPoints(player) {
    var points = 0;
    for (var i = 0; i < players[player].Hand.length; i++) {
        points += players[player].Hand[i].Weight;
        if (points == 21) {
            alert("Player " + players[i].ID + " is the winner!");
            //in the future we will disable player i buttons
        } else if (points > 21) {
            if ((players[player].Hand[0].Value == players[player].Hand[1].Value) && (players[player].Hand[1].Value == "A")) {
                players[player].Hand[1].Weight = 1;
                points -= 10;
            }
        }
    }
    players[player].Points = points;
    return points;
}

//updates the player points 
function updatePoints() {
    for (var i = 0; i < players.length; i++) {
        getPoints(i);
        document.getElementById('points_' + i).innerHTML = players[i].Points;
    }
}

//create the Card UI with HTML Icons
function getCardUI(card) {
    var el = document.createElement('div');
    var icon = '';
    if (card.Suit == 'Hearts')
        icon = '&hearts;';
    else if (card.Suit == 'Spades')
        icon = '&spades;';
    else if (card.Suit == 'Diamonds')
        icon = '&diams;';
    else
        icon = '&clubs;';

    el.className = 'card';
    el.innerHTML = card.Value + '<br/>' + icon;
    return el;
}

//Updates the Deck Length
function updateDeck() {
    console.log("deck after update " + deck.length)
    document.getElementById('deckcount').innerHTML = deck.length;
}

// hit
// player 1 gets 1 card
// card = deck.pop()
// render card ()
// update points() 
//check the points now()
// update deck()

function hit() {
    let card = deck.pop();
    players[currentPlayer].Hand.push(card);
    renderCard(card, currentPlayer);
    updatePoints();
    updateDeck();
    checkPoints();
}

function checkPoints() {
    //check if points is above 21
    if (players[currentPlayer].Points > 21) {
        document.getElementById("status").style.display = "block";
        document.getElementById("status").innerHTML = "Player: " + players[currentPlayer].ID + " LOST!";
        document.getElementById("hitBtn").disabled = true;
        document.getElementById("stayBtn").disabled = true;
    }
    if (players[currentPlayer].Points == 21) {
        endGame();
    }
    if (currentPlayer == players.length - 1) {
        if (players[currentPlayer].Points >= 17) {
            endGame();
        } else {
            hit();
        }
    }
    // need to check situation of 2 players got 20 and it will be a draw 
    // if dealer got 17 or above 

}

//stay
// player 1 stop 
//now dealer turn - currentPlayer ++
//check status of dealer points 
////////// if points > 17 --> endGame()
// endGame() --> compare players points and declare the winner

//else if points < 17 --> hit() --> checkDealerPoints()
//checkDealerPoints() = if points > 17 --> endGame()

//need to remove the active class and add it to next player
//

function stay() {
    if (currentPlayer != players.length - 1) {
        document.getElementById('player_' + currentPlayer).classList.remove('active');
        currentPlayer++;
        document.getElementById('player_' + currentPlayer).classList.add('active');
    } //players.length -1 = 1 , currentplayer = 0

    //check if now the dealer is playing
    //if yes - start automation 
    if (currentPlayer == players.length - 1) {

        hit();

    }
    // else {endGame()}
}

function endGame() {
    alert("game ended");
}

//next steps:
//continue with check points
//endGame function() - draw / winner
//player.score --> need function to update score 
//bank function() --> players that are not dealer